package com.packtpub.springsecurity.data;

public class Category extends BaseModelObject {

}
