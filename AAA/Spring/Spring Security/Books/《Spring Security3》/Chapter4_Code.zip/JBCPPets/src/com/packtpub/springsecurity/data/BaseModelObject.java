package com.packtpub.springsecurity.data;

public class BaseModelObject {

}
