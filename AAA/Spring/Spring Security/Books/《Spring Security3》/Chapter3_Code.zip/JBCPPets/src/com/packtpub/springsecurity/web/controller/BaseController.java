package com.packtpub.springsecurity.web.controller;


/**
 * The base Spring MVC controller. Used to provide common functionality to all controllers.
 * 
 * @author Mularien
 */
public class BaseController {
}
