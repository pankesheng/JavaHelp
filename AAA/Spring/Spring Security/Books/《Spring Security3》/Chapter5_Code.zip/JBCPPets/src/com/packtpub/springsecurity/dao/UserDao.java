package com.packtpub.springsecurity.dao;

public class UserDao implements IUserDao {
}
