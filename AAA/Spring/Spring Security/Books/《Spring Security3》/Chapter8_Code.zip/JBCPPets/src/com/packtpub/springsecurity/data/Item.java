package com.packtpub.springsecurity.data;

public class Item extends BaseModelObject {
	private String title;
	private int price; // in cents
	private Category category;
}
