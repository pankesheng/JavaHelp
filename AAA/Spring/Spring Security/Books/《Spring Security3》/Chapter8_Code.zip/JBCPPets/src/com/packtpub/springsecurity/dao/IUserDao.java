package com.packtpub.springsecurity.dao;

public interface IUserDao {

}